<?php

namespace App\Http\Controllers;

use App\Models\Pizza;
use App\Models\Commande;
use Illuminate\Http\Request;
use App\Models\CommandePizza;
use Illuminate\Support\Facades\DB;

class CommandeController extends Controller
{
    public function consulterCommandes(Request $request, $afficher){
        $commandes = Commande::orderBy('created_at')->paginate(5);
        $articles = CommandePizza::all();
        $pizzas = Pizza::all();
        return view('consultation',['afficher'=>$afficher, 'commandes'=>$commandes, 'articles'=>$articles, 'pizzas'=>$pizzas, 'mode'=>'commandes']);
    }
    
    public function gestionCommandes(){
        $commandes = Commande::orderBy('created_at')->paginate(5);
        $articles = CommandePizza::all();
        $pizzas = Pizza::all();
        return view('gestion',['commandes'=>$commandes, 'articles'=>$articles, 'pizzas'=>$pizzas, 'mode'=>'commandes']);
    }

    public function recherche(Request $request) {
        $commandes = Commande::orderBy('statut', 'desc')->orderBy('created_at')->get();
        $articles = CommandePizza::all();
        $pizzas = Pizza::all();
        $date = $request->annee . "-" . $request->mois . "-" . $request->jour;
        return view('gestion',['commandes'=>$commandes, 'articles'=>$articles, 'pizzas'=>$pizzas, 'mode'=>'commandes', 'recherche'=>$date]);
    }

    public function modif_statut($id, $statut) {
        $commandes = Commande::all(); // INUTILE ?
        $commande = Commande::where('id', $id)->first();
        $commande->statut = $statut;
        $commande->save();

        return redirect() -> route('gestion commandes') -> with('succes', "Le statut a été mis à jour avec succès.");
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Pizza;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function register_view(){
        return view('auth.register');
    }

    public function register(Request $request){
        $request->validate([
            'nom' => 'required|string|max:50',
            'prenom' => 'required|string|max:50',
            'login' => 'required|string|max:30|unique:users',
            'mdp' => 'required|string|confirmed'
        ]);

        $user = new User();
        $user->nom = $request->nom;
        $user->prenom = $request->prenom;
        $user->login = $request->login;
        $user->mdp = Hash::make($request->mdp);
        if (isset($request->fonction)) {
            $user->type = $request->fonction;
        }
        $user->save();
        if (!isset($request->fonction)) {
            Auth::login($user);
        }
        
        $pizzas = Pizza::paginate(3);
        return view('catalogue',['pizzas'=>$pizzas]);
    }

    public function login_view()
    {
        return view('auth.login');
    }

    public function login(Request $request)
    {
        $request -> validate([
            'login' => 'required',
            'mdp' => 'required'
        ]);

        $credentials = ['login' => $request->input('login'),
                        'password' => $request->input('mdp')];


        if (Auth::attempt($credentials)) {
            $request->session()->regenerate(); 
            return redirect()->intended('/catalogue');
        }

        return redirect()->back()->withErrors('Identifiants incorrects');
    }

    public function logout(Request $request)
    {
        Auth::logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect('/');
    }

    public function resetPassword_view()
    {
        return view('auth.reset');
    }

    public function resetPassword(Request $request)
    {
        $request->validate([
            'mdp' => 'required|string|',
            'nouv_mdp' => 'required|string|confirmed'
        ]);
        
        $user = Auth::user();
        if (Hash::check($request->mdp, $user->mdp))
        {
            $user->mdp = Hash::make($request->nouv_mdp);
            $user->save();
            $pizzas = Pizza::paginate(3);
            return redirect() -> route('catalogue pizzas') -> with('succes', "Modification du mot de passe effectuée");
        }
        return redirect()->back()->withErrors('Identifiants incorrects');
    }
    
    public function vue_changer_mdp_cuisto($id) {
        return view('auth.reset_cook', ['id'=>$id]);
    }

    public function changer_mdp_cuisto(Request $request)
    {
        $request->validate([
            'nouv_mdp' => 'required|string|confirmed'
        ]);
        
        $user = User::where('id', $request->id)->first();
        $user->mdp = Hash::make($request->nouv_mdp);
        $user->save();

        return redirect() -> route('gestion utilisateurs') -> with('succes', "Modification du mot de passe effectuée");
    }
}

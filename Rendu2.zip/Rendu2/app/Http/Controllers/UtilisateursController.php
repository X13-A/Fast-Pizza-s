<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Commande;
use Illuminate\Http\Request;
use App\Models\CommandePizza;

class UtilisateursController extends Controller
{
    public function gestionUtilisateurs(){
        $utilisateurs = User::all();
        return view('gestion',['bd'=>$utilisateurs, 'mode'=>'utilisateurs']);
    }
    
    public function ajouter () {
        return view('/auth/register',['mode'=>'admin']);
    }

    public function vue_supprimer($id) {
        $utilisateurs = User::all();
        return view('gestion',['bd'=>$utilisateurs, 'mode'=>'utilisateurs', 'suppr_id'=>$id]);
    }

    public function supprimer($id) {
        $user = User::where('id', $id)->first();
        if ($user->type != "user") {
            $user->forceDelete();
        }
        $utilisateurs = User::all();
        return view('gestion',['bd'=>$utilisateurs, 'mode'=>'utilisateurs']);
    }
}

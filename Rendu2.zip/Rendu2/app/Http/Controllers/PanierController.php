<?php

namespace App\Http\Controllers;

use App\Models\Pizza;
use App\Models\Commande;
use Illuminate\Http\Request;
use App\Models\CommandePizza;
use Illuminate\Support\Facades\Auth;

class PanierController extends Controller
{
    public function ajouter(Request $request, $pizza_id) {

        if (Auth::check() && Auth::user()->type != "user") {
            return redirect() -> route('catalogue pizzas') -> with('erreur', "Seuls les clients peuvent commander.");
        }

        $panier = session()->get('panier');
        if (isset($panier[$pizza_id])) {
            $panier[$pizza_id]["qte"] += 1;
        }
        else {
            $panier[$pizza_id] = [
                "pizza_id"=>$pizza_id,
                "pizza"=>Pizza::where('id', $pizza_id)->first()->nom,
                "qte"=>1,
                "prix"=>Pizza::where('id', $pizza_id)->first()->prix
            ];
        }
        session()->put('panier', $panier);
        return redirect() -> route('catalogue pizzas') -> with('succes', "La pizza a été ajoutée au panier");
    }

    public function supprimer(Request $request, $pizza_id) {
        $panier = session()->get('panier');
        if (isset($panier[$pizza_id])) {
            if ($panier[$pizza_id]["qte"] > 1) {
                $panier[$pizza_id]["qte"] -= 1;
                session()->put('panier', $panier);
                return redirect() -> route('catalogue pizzas') -> with('succes', "Une pizza a été retiré au panier");
            }
            else {
                unset($panier[$pizza_id]);
                session()->put('panier', $panier);
                return redirect() -> route('catalogue pizzas') -> with('succes', "La pizza a été retiré au panier");
            }
        }
    }

    public function envoyer () {
        if (Auth::user()->type != "user") {
            return redirect() -> route('catalogue pizzas') -> with('erreur', "Seuls les clients peuvent commander.");
        }

        $panier = session()->get('panier');
        if ($panier != null) { // enregistre la commande dans la bd
            $uid = Auth::user()->id;
            $commande = new Commande();
            $commande->user_id = $uid;
            $commande->statut = 'envoye';
            $commande->save();

            foreach($panier as $article) { // enregistre chaque pizza de la commande et sa quantité dans la table "commandePizza"
                $achat = new CommandePizza();
                $achat->commande_id = $commande->id;
                $achat->pizza_id = $article["pizza_id"];
                $achat->qte = $article["qte"];
                $achat->save();
            }
            session()->forget('panier');
            return redirect() -> route('catalogue pizzas') -> with('succes', "La commande a été envoyé avec succès.");
        }
        else {
            return redirect() -> route('catalogue pizzas') -> with('erreur', "Votre panier doit contenir au moins un article.");
        }
    }
}

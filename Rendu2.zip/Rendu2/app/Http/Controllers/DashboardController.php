<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Pizza;
use App\Models\Commande;
use Illuminate\Http\Request;
use App\Models\CommandePizza;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    public function welcome()
    {
        return view('/welcome');
    }

    public function catalogue(){
        $pizzas = Pizza::paginate(3);
        return view('catalogue',['pizzas'=>$pizzas]);
    }

    public function contact(){
        return view('contact');
    }
}

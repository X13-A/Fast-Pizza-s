<?php

namespace App\Http\Controllers;

use App\Models\Pizza;
use Illuminate\Http\Request;
use App\Models\CommandePizza;
use Illuminate\Support\Facades\DB;

class PizzaController extends Controller
{
    public function gestionPizzas(){
        // Bloc Utilisé pour restaurer toutes les pizzas supprimés (à des fins de test)
        // $pizzas = Pizza::withTrashed()->get();
        // foreach ($pizzas as $pizza) {
        //     if ($pizza->deleted_at != null) {
        //         $pizza->deleted_at = null;
        //         $pizza->save();
        //     }
        // }
        $pizzas = Pizza::all();
        return view('gestion',['bd'=>$pizzas, 'mode'=>'pizza', 'edit_id'=>0]);
    }

    public function ajouter(Request $request){
        $validatedData = $request->validate([
            'nom' => ['required', 'alpha_dash', 'unique:pizzas'],
            'description' => ['required'],
            'prix' => ['required', 'integer']
        ]);
        $pizza = new Pizza();
        $pizza->nom=$request->nom;
        $pizza->description=$request->description;
        $pizza->prix=$request->prix;
        $pizza->save();

        return redirect() -> route('gestion pizzas') -> with('succes', "La pizza '{$pizza->nom}' a été ajoutée avec succès");
    }

    public function vue_modifier($id){
        $pizzas = Pizza::all();
        return view('gestion',['bd'=>$pizzas, 'mode'=>'pizza', 'edit_id'=>$id, 'action'=>'modifier']);
    }

    public function modifier(Request $request, $id){
        $validatedData = $request->validate([
            'nom' => ['required', 'alpha_dash'],
            'description' => ['required'],
            'prix' => ['required', 'integer']
        ]);

        $pizza = Pizza::where('id', $id)->first();
        $pizza->nom=$request->nom;
        $pizza->description=$request->description;
        $pizza->prix=$request->prix;
        $pizza->save();

        return redirect() -> route('gestion pizzas') -> with('succes', "La pizza '{$pizza->nom}' a été modifiée avec succès");
    }
    
    public function vue_supprimer($id){
        $pizzas = Pizza::all();
        return view('gestion',['bd'=>$pizzas, 'mode'=>'pizza', 'edit_id'=>$id, 'action'=>'supprimer']);
    }

    public function supprimer($id){
        $pizza = Pizza::where('id', $id)->first();
        $commande = CommandePizza::where('pizza_id', $id)->first();
        if ($commande != null){
            $pizza->delete();
        }
        else {
            $pizza->forceDelete();
        }
        return redirect() -> route('gestion pizzas') -> with('succes', "La pizza '{$pizza->nom}' a été supprimée avec succès");
    }
}

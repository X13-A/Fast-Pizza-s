@extends('layouts.app')
@section('content')

@yield('gestion')

@endsection
@extends('layouts.app')
@section('content')
<div class="container page">
    <form action="{{ route('changer mot de passe') }}" style="width: 30%; text-align: left;" method="post" class="center">
        @csrf
        <span style="font-size: 1.3em;">Mot de passe actuel:</span> <br>
        <input class="clean" type="password" name="mdp" placeholder="Entrez votre mot de passe" style="width: 100%; margin: 1em 0;"> <br>
        <span style="font-size: 1.3em;" >Nouveau mot de passe:</span>
        <input class="clean" type="password" name="nouv_mdp" placeholder="Entrez votre nouveau mot de passe" style="width: 100%; margin: 1em 0;"> <br>
        <input class="clean" type="password" name="nouv_mdp_confirmation" placeholder="Confirmez votre nouveau mot de passe" style="width: 100%; margin: 1em 0;"> <br>
        <button class="clean" type="submit" style="width: 100%; margin-bottom:0.4em;">Changer de mot de passe</button>
    </form>
</div>

@endsection
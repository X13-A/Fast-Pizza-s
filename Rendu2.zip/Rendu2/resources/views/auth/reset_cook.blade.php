@extends('layouts.app')
@section('content')

<div class="container page">
    <form action="{{ route('changer mdp cuisto') }}" style="width: 30%; text-align: left;" method="post" class="center">
        @csrf
        <span style="font-size: 1.3em;" >Nouveau mot de passe:</span>
        <input class="clean" type="password" name="nouv_mdp" placeholder="Entrez le nouveau mot de passe" style="width: 100%; margin: 1em 0;"> <br>
        <input class="clean" type="password" name="nouv_mdp_confirmation" placeholder="Confirmez le nouveau mot de passe" style="width: 100%; margin: 1em 0;"> <br>
        <input type="text" name="id" hidden value="{{$id}}">
        <button class="clean" type="submit" style="width: 100%; margin-bottom:0.4em;">Changer le mot de passe</button>
    </form>
</div>

@endsection
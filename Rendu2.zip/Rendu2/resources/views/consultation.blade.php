@extends('dashboard')
@section('gestion')

@if ($mode == 'commandes')
    @include('consultation.commandes')
@endif

@endsection

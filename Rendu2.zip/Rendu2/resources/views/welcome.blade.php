@extends('layouts.app')
@section('content')
<div class="container" style="text-align: center; padding-top: 5em">
    <h3>Bienvenue chez Fast pizza's !</h3>
    <h5>Créez un compte ou connectez-vous pour choisir parmis des dizaines de pizzas.</h5>
</div>
@endsection
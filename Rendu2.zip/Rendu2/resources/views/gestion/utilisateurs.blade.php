<div class="container" style="margin-bottom: 3em; margin-top:2em;">
    <a class="shop" href="{{ route('ajout utilisateur') }}">Ajouter un utilisateur</a>
    <!-- Table contentant tous les utilisateurs et leurs informations -->
    <table id="catalogue" class="table table-striped table-bordered nowrap" style="width:100%">
        <thead>
            <tr>
                <th>Id</th>
                <th>Nom</th>
                <th>Prénom</th>
                <th>Login</th>
                <th>Type</th>
                <th></th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            @foreach ($bd as $utilisateur)
                <tr>
                    <td> {{$utilisateur -> id}} </td>
                    <td> {{$utilisateur -> nom}} </td>
                    <td> {{$utilisateur -> prenom}} </td>
                    <td> {{$utilisateur -> login}} </td>
                    <td> {{$utilisateur -> type}} </td>
                    @if (isset($suppr_id) && $suppr_id == $utilisateur->id)
                        <td> <a class="shop" href="{{route('supprimer utilisateur',['id'=>$utilisateur->id])}}"> confirmer </a> </td>
                        <td> <a class="shop" href="{{route('gestion utilisateurs')}}"> annuler </a></td>
                    @else
                        @if($utilisateur-> type != "user")
                            <td> <a class="shop" href="{{route('vue supprimer utilisateur',['id'=>$utilisateur->id])}}"> supprimer </a></td>
                        @else
                            <td></td>
                        @endif
                        @if($utilisateur->type == "cook")
                            <td> <a class="shop" href="{{route('vue changer mdp cuisto',['id'=>$utilisateur->id])}}"> modifier mdp </a> </td>
                        @else
                            <td></td>
                        @endif
                    @endif
                </tr>
            @endforeach
        </tbody>
    </table>
</div>

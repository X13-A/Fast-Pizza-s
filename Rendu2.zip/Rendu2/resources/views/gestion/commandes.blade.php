<?php
    use App\Models\User;
    use App\Models\Pizza;
?>

<!-- Ce bloc permet de rassembler toutes les informations dans la variable
"info_commandes", afin de les afficher plus facilement par la suite -->

<?php
    foreach($commandes as $commande) {
        $info_commandes[$commande->id] = [
            "user"=>User::where('id', $commande->user_id)->first()->nom . " " . User::where('id', $commande->user_id)->first()->prenom,
            "creation"=>$commande->created_at,
            "modification"=>$commande->updated_at,  
            "statut"=>$commande->statut,
            "id"=> $commande->id,
        ];
        foreach($articles as $article) {
            if ($article->commande_id == $commande->id){
                $info_commandes[$commande->id]["pizzas"][$article->pizza_id]["nom"]
                = Pizza::where('id', $article->pizza_id)->withTrashed()->first()->nom;
                $info_commandes[$commande->id]["pizzas"][$article->pizza_id]["prix"]
                = Pizza::where('id', $article->pizza_id)->withTrashed()->first()->prix;
                $info_commandes[$commande->id]["pizzas"][$article->pizza_id]["qte"]
                = $article->qte;
            }
        }
    }
?>

<div class="container" style="margin-bottom: 3em; margin-top:2em;">
    @if(Auth::user()->type != "cook") <!-- Pour que le cuisto ne voie pas ces informations -->
        <!-- Formulaire permettant de rechercher à l'aide d'une date dans la liste des commandes -->
        <div>
            <form action="{{route('recherche commande')}}" style="margin-bottom: 1em;" method="get">
                @csrf
                <input class="clean" type="text" id="jour" name="jour" placeholder="Jour" value="{{old('jour')}}">
                <input class="clean" type="text" id="mois" name="mois" placeholder="Mois" value="{{old('mois')}}">
                <input class="clean" type="text" id="annee" name="annee" placeholder="Année" value="{{old('annee')}}">
                <button class="a shop" type="submit">Rechercher</button>
            </form>
        </div>

        <div style="margin-bottom: 1em;">
        <!-- Affiche les détails du filtre et propose de le supprimer -->
            <?php
                if(isset($recherche)) { 
                    echo("Affichage des commandes effectuées le " . $recherche . ".");
                }
            ?>
            <a class="shop" style="margin-right: 1em;" href="{{ route('gestion commandes') }}"> Effacer le filtre </a>
            <!-- Permet d'afficher les commandes du jour -->
            <form action="{{route('recherche commande')}}" style="margin-bottom: 1em;" method="get">
                @csrf
                <input type="hidden" id="jour" name="jour" placeholder="Jour" value="{{date('d')}}">
                <input type="hidden" id="mois" name="mois" placeholder="Mois" value="{{date('m')}}">
                <input type="hidden" id="annee" name="annee" placeholder="Année" value="{{date('Y')}}">
                <button class="a shop" type="submit">Afficher les commandes du jour</button>
            </form>
        </div>
    @endif
    
    <!-- Tableau contenant les commandes -->
    <table id="catalogue" class="table table-striped table-bordered nowrap" style="width:100%">
        <thead>
            <tr>
                <th style="width:10em;">Client</th>
                <th style="width:10em;">Statut</th>
                <th>Date de création</th>
                <th>Date d'édition</th>
            </tr>
        </thead>
        <tbody>
            <?php $row = 0; ?>
            <?php $recette = 0;?>
            @if (isset($info_commandes))
                @foreach ($info_commandes as $commande)
                    @if ($commande["statut"] != "recupere" || Auth::user()->type != "cook") <!-- Pour que le cuisto ne voie que les commandes en cours -->
                        <?php $row += 1; ?>
                        <?php $print = false; ?>
                        <!-- Condition qui détermine si une commande doit être affichée ou non-->
                        <?php
                            if(!isset($recherche) || (isset($recherche) && str_contains($commande["creation"], $recherche))) {
                                $print = true;
                            }
                        ?>
                        @if($print)
                            <tr>
                                <td> {{$commande["user"]}} </td>
                                <td> 
                                    <div style="display:inline-block;">
                                        <div class="dropdown">
                                            <button class="btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <!-- Ce switch permet juste d'afficher les mots avec des majuscules/accents, pas comme dans la bd -->
                                                @switch($commande["statut"]) 
                                                    @case("envoye")
                                                        Envoyée
                                                        @break
                                                    @case("traitement") 
                                                        Traitement
                                                        @break
                                                    @case("pret")
                                                        Prête
                                                        @break
                                                    @case("recupere")
                                                        Récupérée
                                                        @break
                                                @endswitch
                                            </button>
                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                @if ($commande["statut"] != "envoye")
                                                    <a class="dropdown-item" href="{{route('modif statut',['id'=>$commande['id'], 'statut'=>'envoye'])}}">Envoyée</a>
                                                @endif
                                                @if ($commande["statut"] != "traitement")
                                                    <a class="dropdown-item" href="{{route('modif statut',['id'=>$commande['id'], 'statut'=>'traitement'])}}">Traitement</a>
                                                @endif
                                                @if ($commande["statut"] != "pret")
                                                    <a class="dropdown-item" href="{{route('modif statut',['id'=>$commande['id'], 'statut'=>'pret'])}}">Prête</a>
                                                @endif
                                                @if ($commande["statut"] != "recupere")
                                                    <a class="dropdown-item" href="{{route('modif statut',['id'=>$commande['id'], 'statut'=>'recupere'])}}">Récupérée</a>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td> {{$commande["creation"]}} </td>
                                <td> {{$commande["modification"]}} </td>
                                <?php $id = "show_" . $row; ?>
                                <td><a class="shop" href="#" id={{$id}}>Détails</a></td>
                            </tr>
                            <tr>
                                <td colspan="4">
                                    <?php $id = "extra_" . $row; ?>
                                    <div id={{$id}} style="display: none;">
                                        <?php $total = 0;?>
                                        <!-- calcul de la recette et du total des commandes-->
                                        @foreach ($commande["pizzas"] as $pizza)
                                            <span style="padding-right: 1em;"> {{$pizza["nom"]}} </span>
                                            <span> x{{$pizza["qte"]}} </span>
                                            <br>
                                            <?php $total += $pizza["prix"] ?>
                                        @endforeach
                                        <span>Total: {{$total}}€</span>
                                        <?php $recette += $total; ?>
                                    </div>
                                </td>
                            </tr>
                        @endif
                    @endif
                @endforeach
            @endif
        </tbody>
    </table>
    @if (isset($recherche))
        <h4>Recette: {{$recette}}€</h4>
    @else
        </span>{{$commandes -> links()}}</span>
    @endif
    </div>

<!-- Script permettant d'afficher le détail des commandes -->

<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script> 
    $("a[id^=show_]").click(function(event) {
        $("#extra_" + $(this).attr('id').substr(5)).slideToggle("fast");
        event.preventDefault();
    });
</script>
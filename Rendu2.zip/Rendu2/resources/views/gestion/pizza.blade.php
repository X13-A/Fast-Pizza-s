<!-- menu permettant d'ajouter une pizza -->
<div class="container" style="margin-top: 2em;">
    <form action="/ajout_pizza" method="POST">
        @csrf
        <div>
            <input class="clean" type="text" id="nom" name="nom" placeholder="Nom" value="{{old('nom')}}">
            <input class="clean" type="text" id="description" name="description" placeholder="Description" value="{{old('description')}}">
            <input class="clean" type="text" id="prix" name="prix" placeholder="Prix" value="{{old('prix')}}">
            <button class="clean" type="submit">Ajouter une pizza</button>
        </div>
    </form>
</div>

<!-- table contentant tout le catalogue -->
<div class="container" style="margin-bottom: 3em; margin-top:2em;">
    <table id="catalogue" class="table table-striped table-bordered nowrap" style="width:100%">
        <thead>
            <tr>
                <th>Nom</th>
                <th>Description</th>
                <th>Prix</th>
                <th></th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            @foreach ($bd as $pizza)
                <tr>
                    <!-- Si une action est en train d'être faite, on affiche les objects correspondants. (form, confirmation) -->
                    @if ($edit_id == $pizza->id && isset($action)) 
                        @if ($action == 'modifier')
                            <form action="{{route('modif pizza',['id'=>$pizza->id])}}" method="POST">
                                @csrf
                                <td> <input type="text" id="nom" name="nom" value="{{$pizza -> nom}}"> </td>
                                <td> <input style="width:100%;" type="text" id="description" name="description" value="{{$pizza -> description}}"> </td>
                                <td> <input type="text" id="prix" name="prix" value="{{$pizza -> prix}}"> </td>
                                <td> <button class="icon" type="submit"> confirmer </button> </td>
                                <td> <a class="shop" href="{{route('gestion pizzas')}}"> annuler </a></td>
                            </form>
                        @elseif ($action == 'supprimer')
                            <td> {{$pizza -> nom}} </td>
                            <td> {{$pizza -> description}} </td>
                            <td> {{$pizza -> prix}} €</td>
                            <td> <a class="shop" href="{{route('supprimer pizza',['id'=>$pizza->id])}}"> confirmer </a> </td>
                            <td> <a class="shop" href="{{route('gestion pizzas')}}"> annuler </a></td>
                        @endif
                    @else
                        <!-- Sinon on affiche juste les pizzas avec les actions possibles -->
                        <td> {{$pizza -> nom}} </td>
                        <td> {{$pizza -> description}} </td>
                        <td> {{$pizza -> prix}} €</td>
                        <td> <a class="shop" href="{{route('vue modif pizza',['id'=>$pizza->id])}}"> modifier </a> </td>
                        <td> <a class="shop" href="{{route('vue supprimer pizza',['id'=>$pizza->id])}}"> supprimer </a></td>
                    @endif
                </tr>
            @endforeach
        </tbody>
    </table>
</div>


@extends('layouts.app')
@section('content')

<div class="container center" style="width:40%; text-align: left; padding-top: 5em">
    <h4>Téléphone: 06 91 02 89 23</h4>
    <h4>Mail: fastpizzas@hotmail.com</h4> <br>
    <h4>Adresse: 1 rue de lyon, 75012 Paris</h4>
</div>

@endsection
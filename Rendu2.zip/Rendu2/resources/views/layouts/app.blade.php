<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fast Pizza's</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="{{ URL::asset('css/app.css') }}">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>
<body>
    <!-- Le header avec les boutons principaux. -->
    <header> 
        <img class="logo" src="{{URL::asset('/img/logo.png')}}" alt="pizza" height="100" width="100">
        <ul class="nav__links">
            <li>
                <a href="{{ route('welcome') }}"> Accueil </a>
            </li>
            <li>
                <a href="{{ route('catalogue pizzas') }}"> Catalogue </a>
            </li>
            <li style="border: none;">
                <a href="{{ route('contact') }}"> Contact </a>
            </li>
        </ul>
        <!-- Menu utilisateur -->
        <div class="dropdown">
            <button class="btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                @auth
                <span class="material-icons">face</span>
                <span>{{ auth()->user()->prenom }} {{ auth()->user()->nom }}</span>
                @endauth
                @guest
                <span class="material-icons">account_circle</span>
                <span>S'identifier</span>
                @endguest
            </button>
            <div class="dropdown-menu bg-white" aria-labelledby="dropdownMenuButton">
                @auth
                    <a class="dropdown-item" href="{{ route('vue changer mot de passe') }}"> Changer mon mot de passe </a>
                    <a class="dropdown-item" href="{{ route('logout') }}" method="post"> Déconnexion </a>
                    @if(Auth::user()->type == 'user')
                        <a class="dropdown-item" href="{{ route('consulter commandes',['afficher'=>'tout']) }}"> Mes commandes </a>
                    @elseif(Auth::user()->type == 'admin')
                        <a class="dropdown-item" href="{{ route('gestion commandes') }}"> Gestion commandes</a>
                        <a class="dropdown-item" href="{{ route('gestion pizzas') }}"> Gestion pizzas</a>
                        <a class="dropdown-item" href="{{ route('gestion utilisateurs') }}"> Gestion Utilisateurs</a>
                    @elseif (Auth::user()->type == 'cook')
                        <a class="dropdown-item" href="{{ route('gestion commandes') }}"> Commandes</a>
                    @endif
                @endauth
                @guest
                    <a class="dropdown-item" href="{{ route('login') }}"> Se connecter </a>
                    <a class="dropdown-item" href="{{ route('register') }}"> S'inscrire </a>                
                @endguest
            </div>
        </div>
    </header>
    
    @yield('content')

    <div class="container" >
        <!-- Affichage des messages flash de confirmation si il y en a -->
        @if (session()->has('succes'))
            <div class="alert alert-success" role="alert">
                {{session()->get('succes')}}
            </div>
        @endif

        <!-- Affichage des messages flash d'erreur si il y en a -->
        @if (session()->has('erreur'))
            <div class="alert alert-danger" role="alert">
                {{session()->get('erreur')}}
            </div>
        @endif

        <!-- Affichage des messages flash d'erreurs de validation si il y en a -->
        @if ($errors->any())
            @foreach ($errors->all() as $error)
                <div class="alert alert-danger" role="alert"> {{ $error }} </div>
            @endforeach
        @endif
    </div>
</body>
</html>
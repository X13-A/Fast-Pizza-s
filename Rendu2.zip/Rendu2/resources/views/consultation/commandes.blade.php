<?php
    use App\Models\User;
    use App\Models\Pizza;
?>

<!-- Ce bloc permet de rassembler toutes les informations dans la variable
"info_commandes", afin de les afficher plus facilement par la suite -->

<?php
    foreach($commandes as $commande) {
        if ($commande->user_id == Auth::user()->id) {
            $info_commandes[$commande->id] = [
                "user"=>User::where('id', $commande->user_id)->first()->nom . " " . User::where('id', $commande->user_id)->first()->prenom,
                "creation"=>$commande->created_at,
                "modification"=>$commande->updated_at,  
                "statut"=>$commande->statut,
                "id"=> $commande->id,
            ];
            foreach($articles as $article) {
                if ($article->commande_id == $commande->id){
                    $info_commandes[$commande->id]["pizzas"][$article->pizza_id]["nom"]
                    = Pizza::where('id', $article->pizza_id)->withTrashed()->first()->nom;
                    $info_commandes[$commande->id]["pizzas"][$article->pizza_id]["qte"]
                    = $article->qte;
                }
            }   
        }
    }
?>

<!-- Affiche toutes les commandes de l'utilisateur et leur détail dans un tableau -->

<div class="container" style="margin-bottom: 3em; margin-top:2em;">
    <div class="dropdown" style="margin-bottom: 2em;">
        <button class="btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Afficher {{$afficher}}
        </button>
        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <!-- Permet simplement de ne pas afficher l'option si elle est déjà séléctionnée -->
            @if ($afficher != "tout") 
                <a class="dropdown-item" href="{{ route('consulter commandes',['afficher'=>'tout']) }}">Tout</a>
            @endif
            @if ($afficher != "en cours")
                <a class="dropdown-item" href="{{ route('consulter commandes',['afficher'=>'en cours']) }}">En cours</a>
            @endif
        </div>
    </div>
    <table id="catalogue" class="table table-striped table-bordered nowrap" style="width:100%">
        <thead>
            <tr>
                <th style="width:10em;">Date</th>
                <th style="width:10em;">Statut</th>
                <th style="width:10em;">Total</th>
            </tr>
        </thead>
        <tbody>
            <?php $row = 0; ?>
            @if (isset($info_commandes)) 
                @foreach ($info_commandes as $commande)
                    @if($afficher == "tout" || $commande["statut"] != "recupere")
                        <?php $row += 1; ?>
                        <tr>
                            <td> {{$commande["creation"]}} </td>
                            <td> {{$commande["statut"]}} </td>
                            <td>
                                <?php
                                    $total = 0;
                                    foreach ($commande["pizzas"] as $pizza) {
                                        $total += Pizza::where('nom', $pizza["nom"])->first()->prix * $pizza["qte"];
                                    }
                                ?>
                                {{$total}} €
                            </td>
                            <?php $id = "show_" . $row; ?>
                            <td><a href="#" id={{$id}}>Détails</a></td>
                        </tr>
                        <tr>
                            <td colspan="4">
                                <?php $id = "extra_" . $row; ?>
                                <div id={{$id}} style="display: none;">
                                    <!-- Détail de la commande -->
                                    @foreach ($commande["pizzas"] as $pizza) 
                                        <span style="padding-right: 1em;"> {{$pizza["nom"]}} </span>
                                        <span> x{{$pizza["qte"]}} </span>
                                        <br>
                                    @endforeach
                                </div>
                            </td>
                        </tr>
                    @endif
                @endforeach
            @endif
        </tbody>
    </table>
    </span>{{$commandes -> links()}}</span>
</div>

<!-- Script permettant d'affiche ou non le détail des commandes -->

<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script>
    $("a[id^=show_]").click(function(event) {
        $("#extra_" + $(this).attr('id').substr(5)).slideToggle("fast");
        event.preventDefault();
    });
</script>
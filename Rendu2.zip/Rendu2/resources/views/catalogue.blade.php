<?php use App\Models\Pizza; ?>
@extends('layouts.app')
@section('content')

<!-- Affiche toutes les pizzas -->
<div class="container" style="margin-bottom: 3em; margin-top:2em;">
    <h3>Catalogue</h3>
    <table id="catalogue" class="table table-striped table-bordered nowrap" style="width:100%">
        <thead>
            <tr>
                <th>Pizza</th>
                <th>Ingrédients</th>
                <th>Prix</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            @foreach ($pizzas as $pizza)
                <tr>
                    <td> {{$pizza -> nom}} </td>
                    <td> {{$pizza -> description}} </td>
                    <td> {{$pizza -> prix}}€</td>
                    <td> <a class="material-icons shop" href="{{ route('ajouter panier',['pizza_id'=>$pizza->id]) }}">add</a> </td> 
                </tr>
            @endforeach
        </tbody>
    </table>
    {{$pizzas -> links()}}
</div>

<!-- affiche le panier -->
<div class="container" style="margin-bottom: 3em; margin-top:2em;">
    <h3>Panier</h3>
    <table id="panier" class="table table-striped table-bordered nowrap" style="width:100%">
        <thead>
            <tr>
                <th>Pizza</th>
                <th>Quantité</th>
                <th>Prix</th>
            </tr>
        </thead>
        <tbody>
            <?php $panier = session()->get('panier'); ?>
            @if ($panier != null)
                @foreach ($panier as $article)
                    <tr>
                        <td> {{$article["pizza"]}} </td>
                        <td> {{$article["qte"]}} </td>
                        <td> {{$article["prix"]}}€ </td>
                        <td> <a class="shop" href="{{ route('supprimer panier',['pizza_id'=>$article['pizza_id']]) }}"> Enlever </a> </td>
                    </tr>
                @endforeach
            @endif
        </tbody>
        <tfoot>
            <?php
                $total = 0;
                if ($panier != null) {
                    foreach ($panier as $article) {
                        $total += $article["prix"] * $article["qte"];
                    }
                }
                echo("<tr>");
                echo("<th>Total: $total €</th>");
                echo("</tr></table>");
            ?>
        </tfoot>
        <th><a class="shop" href="{{ route('envoyer commande') }}"> Envoyer la commande </a></th>
    </table>
</div>

@endsection
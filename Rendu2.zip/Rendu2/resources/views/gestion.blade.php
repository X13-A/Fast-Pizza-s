@extends('dashboard')
@section('gestion')

@if ($mode == 'pizza')
    @include('gestion.pizza')
@elseif ($mode == 'commandes')
    @include('gestion.commandes')
@elseif ($mode == 'utilisateurs')
    @include('gestion.utilisateurs')
@endif

@endsection

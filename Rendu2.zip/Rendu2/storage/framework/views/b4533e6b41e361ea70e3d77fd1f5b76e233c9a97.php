
<?php $__env->startSection('content'); ?>

<div class="container page">
    <form action="<?php echo e(route('changer mdp cuisto')); ?>" style="width: 30%; text-align: left;" method="post" class="center">
        <?php echo csrf_field(); ?>
        <span style="font-size: 1.3em;" >Nouveau mot de passe:</span>
        <input class="clean" type="password" name="nouv_mdp" placeholder="Entrez le nouveau mot de passe" style="width: 100%; margin: 1em 0;"> <br>
        <input class="clean" type="password" name="nouv_mdp_confirmation" placeholder="Confirmez le nouveau mot de passe" style="width: 100%; margin: 1em 0;"> <br>
        <input type="text" name="id" hidden value="<?php echo e($id); ?>">
        <button class="clean" type="submit" style="width: 100%; margin-bottom:0.4em;">Changer le mot de passe</button>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Software\Wamp\www\TM\TM3\Pizza\resources\views/auth/reset_cook.blade.php ENDPATH**/ ?>
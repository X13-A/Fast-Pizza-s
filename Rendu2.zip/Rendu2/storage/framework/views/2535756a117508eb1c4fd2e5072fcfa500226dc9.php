
<?php $__env->startSection('content'); ?>

<div class="container page" style="margin-top: 2em;">
    <form action="<?php echo e(route('register')); ?>" method="post" style="width: 30%; text-align: left;" class="center">
        <?php echo csrf_field(); ?>
        
        <!-- Si un mode est définit, c'est l'admin qui accède à la page et il peut donc modifier le type du nouvel utilisateur -->
        <?php if(isset($mode)): ?> 
            <span style="font-size: 1.3em;">Fonction:</span> <br> 
            <input type="radio" name="fonction" value="user" checked><span style="margin-left: 0.6em;">Utilisateur</span><br>
            <input type="radio" name="fonction" value="cook"><span style="margin-left: 0.6em;">Cuisinier</span><br>
            <input type="radio" name="fonction" value="admin"><span style="margin-left: 0.6em;">Administrateur</span><br><br>
        <?php endif; ?>
        <span style="font-size: 1.3em;">Nom:</span> <br> 
        <input class="clean" type="text" name="nom" placeholder="Entrez votre nom" value="<?php echo e(old('nom')); ?>" style="width: 100%; margin: 1em 0;"><br>
        <span style="font-size: 1.3em;">Prénom:</span> <br> 
        <input class="clean" type="text" name="prenom" placeholder="Entrez votre prénom" value="<?php echo e(old('prenom')); ?>" style="width: 100%; margin: 1em 0;"><br>
        <span style="font-size: 1.3em;">Login:</span> <br> 
        <input class="clean" type="text" name="login" placeholder="Entrez votre login" value="<?php echo e(old('login')); ?>" style="width: 100%; margin: 1em 0;"><br>
        <span style="font-size: 1.3em;">Mot de passe:</span> <br> 
        <input class="clean" type="password" name="mdp" placeholder="Entrez votre mot de passe" value="<?php echo e(old('mdp')); ?>" style="width: 100%; margin-top: 1em; margin-bottom: 0.5em;"><br>
        <input class="clean" type="password" name="mdp_confirmation" placeholder="Confirmez votre mot de passe" value="<?php echo e(old('mdp_confirmation')); ?>" style="width: 100%; margin-bottom: 1em;">
        <button class="clean" type="submit" style="width: 100%; margin-bottom:0.4em;">S'inscrire</button>
    </form>

    <!-- Si un mode est définit, cela veut dire que l'admin accède à cette page pour ajouter un utilisateur, donc il n'a pas besoin de ce lien -->
    <?php if(!isset($mode)): ?> 
        <div style="width: 30%; text-align: left;" class="center">
            <span>Vous avez déjà un compte ?</span>
            <a class="shop" href="<?php echo e(route('login view')); ?>"> Connectez-vous</a>
        </div>
    <?php endif; ?>
</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Software\Wamp\www\TM\TM3\Pizza\resources\views/auth/register.blade.php ENDPATH**/ ?>
<div class="container" style="margin-bottom: 3em; margin-top:2em;">
    <a class="shop" href="<?php echo e(route('ajout utilisateur')); ?>">Ajouter un utilisateur</a>
    <!-- Table contentant tous les utilisateurs et leurs informations -->
    <table id="catalogue" class="table table-striped table-bordered nowrap" style="width:100%">
        <thead>
            <tr>
                <th>Id</th>
                <th>Nom</th>
                <th>Prénom</th>
                <th>Login</th>
                <th>Type</th>
                <th></th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $bd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $utilisateur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($utilisateur -> id); ?> </td>
                    <td> <?php echo e($utilisateur -> nom); ?> </td>
                    <td> <?php echo e($utilisateur -> prenom); ?> </td>
                    <td> <?php echo e($utilisateur -> login); ?> </td>
                    <td> <?php echo e($utilisateur -> type); ?> </td>
                    <?php if(isset($suppr_id) && $suppr_id == $utilisateur->id): ?>
                        <td> <a class="shop" href="<?php echo e(route('supprimer utilisateur',['id'=>$utilisateur->id])); ?>"> confirmer </a> </td>
                        <td> <a class="shop" href="<?php echo e(route('gestion utilisateurs')); ?>"> annuler </a></td>
                    <?php else: ?>
                        <?php if($utilisateur-> type != "user"): ?>
                            <td> <a class="shop" href="<?php echo e(route('vue supprimer utilisateur',['id'=>$utilisateur->id])); ?>"> supprimer </a></td>
                        <?php else: ?>
                            <td></td>
                        <?php endif; ?>
                        <?php if($utilisateur->type == "cook"): ?>
                            <td> <a class="shop" href="<?php echo e(route('vue changer mdp cuisto',['id'=>$utilisateur->id])); ?>"> modifier mdp </a> </td>
                        <?php else: ?>
                            <td></td>
                        <?php endif; ?>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH D:\Software\Wamp\www\TM\TM3\Pizza\resources\views/gestion/utilisateurs.blade.php ENDPATH**/ ?>
<?php
    use App\Models\User;
    use App\Models\Pizza;
?>

<!-- Ce bloc permet de rassembler toutes les informations dans la variable
"info_commandes", afin de les afficher plus facilement par la suite -->

<?php
    foreach($commandes as $commande) {
        if ($commande->user_id == Auth::user()->id) {
            $info_commandes[$commande->id] = [
                "user"=>User::where('id', $commande->user_id)->first()->nom . " " . User::where('id', $commande->user_id)->first()->prenom,
                "creation"=>$commande->created_at,
                "modification"=>$commande->updated_at,  
                "statut"=>$commande->statut,
                "id"=> $commande->id,
            ];
            foreach($articles as $article) {
                if ($article->commande_id == $commande->id){
                    $info_commandes[$commande->id]["pizzas"][$article->pizza_id]["nom"]
                    = Pizza::where('id', $article->pizza_id)->withTrashed()->first()->nom;
                    $info_commandes[$commande->id]["pizzas"][$article->pizza_id]["qte"]
                    = $article->qte;
                }
            }   
        }
    }
?>

<!-- Affiche toutes les commandes de l'utilisateur et leur détail dans un tableau -->

<div class="container" style="margin-bottom: 3em; margin-top:2em;">
    <div class="dropdown" style="margin-bottom: 2em;">
        <button class="btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Afficher <?php echo e($afficher); ?>

        </button>
        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <!-- Permet simplement de ne pas afficher l'option si elle est déjà séléctionnée -->
            <?php if($afficher != "tout"): ?> 
                <a class="dropdown-item" href="<?php echo e(route('consulter commandes',['afficher'=>'tout'])); ?>">Tout</a>
            <?php endif; ?>
            <?php if($afficher != "en cours"): ?>
                <a class="dropdown-item" href="<?php echo e(route('consulter commandes',['afficher'=>'en cours'])); ?>">En cours</a>
            <?php endif; ?>
        </div>
    </div>
    <table id="catalogue" class="table table-striped table-bordered nowrap" style="width:100%">
        <thead>
            <tr>
                <th style="width:10em;">Date</th>
                <th style="width:10em;">Statut</th>
                <th style="width:10em;">Total</th>
            </tr>
        </thead>
        <tbody>
            <?php $row = 0; ?>
            <?php if(isset($info_commandes)): ?> 
                <?php $__currentLoopData = $info_commandes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commande): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($afficher == "tout" || $commande["statut"] != "recupere"): ?>
                        <?php $row += 1; ?>
                        <tr>
                            <td> <?php echo e($commande["creation"]); ?> </td>
                            <td> <?php echo e($commande["statut"]); ?> </td>
                            <td>
                                <?php
                                    $total = 0;
                                    foreach ($commande["pizzas"] as $pizza) {
                                        $total += Pizza::where('nom', $pizza["nom"])->first()->prix * $pizza["qte"];
                                    }
                                ?>
                                <?php echo e($total); ?> €
                            </td>
                            <?php $id = "show_" . $row; ?>
                            <td><a href="#" id=<?php echo e($id); ?>>Détails</a></td>
                        </tr>
                        <tr>
                            <td colspan="4">
                                <?php $id = "extra_" . $row; ?>
                                <div id=<?php echo e($id); ?> style="display: none;">
                                    <!-- Détail de la commande -->
                                    <?php $__currentLoopData = $commande["pizzas"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pizza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                        <span style="padding-right: 1em;"> <?php echo e($pizza["nom"]); ?> </span>
                                        <span> x<?php echo e($pizza["qte"]); ?> </span>
                                        <br>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>
    </span><?php echo e($commandes -> links()); ?></span>
</div>

<!-- Script permettant d'affiche ou non le détail des commandes -->

<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script>
    $("a[id^=show_]").click(function(event) {
        $("#extra_" + $(this).attr('id').substr(5)).slideToggle("fast");
        event.preventDefault();
    });
</script><?php /**PATH D:\Software\Wamp\www\TM\TM3\Pizza\resources\views/consultation/commandes.blade.php ENDPATH**/ ?>
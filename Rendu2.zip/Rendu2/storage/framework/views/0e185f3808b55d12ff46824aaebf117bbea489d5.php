
<?php $__env->startSection('content'); ?>

<div class="container page">
    <form method="post" style="width: 25%; text-align: left;" class="center">
        <?php echo csrf_field(); ?>
        <span style="font-size: 1.3em;">Login:</span> <br> 
        <input class="clean" type="text" name="login" value="<?php echo e(old('login')); ?>" style="width: 100%; margin: 1em 0;" placeholder="Entrez votre login"> <br>
        <span style="font-size: 1.3em;">Mot de passe:</span> <br>
        <input class="clean" type="password" name="mdp" style="width: 100%; margin: 1em 0;" placeholder="Entrez votre mot de passe"> <br>
        <button class="clean" type="submit" style="width: 100%; height: 2em; ">Se connecter</button>
    </form>
    <div style="width: 25%; text-align: left;" class="center">
        <span>Vous n'avez pas de compte ?</span>
        <a class="shop" href="<?php echo e(route('register')); ?>"> S'inscrire.</a>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Software\Wamp\www\TM\TM3\Pizza\resources\views/auth/login.blade.php ENDPATH**/ ?>
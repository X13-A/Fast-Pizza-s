
<?php $__env->startSection('gestion'); ?>

<?php if($mode == 'pizza'): ?>
    <?php echo $__env->make('gestion.pizza', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php elseif($mode == 'commandes'): ?>
    <?php echo $__env->make('gestion.commandes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php elseif($mode == 'utilisateurs'): ?>
    <?php echo $__env->make('gestion.utilisateurs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Software\Wamp\www\TM\TM3\Pizza\resources\views/gestion.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>
<div class="container" style="text-align: center; padding-top: 5em">
    <h3>Bienvenue chez Fast pizza's !</h3>
    <h5>Créez un compte ou connectez-vous pour choisir parmis des dizaines de pizzas.</h5>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Software\Wamp\www\TM\TM3\Pizza\resources\views//welcome.blade.php ENDPATH**/ ?>
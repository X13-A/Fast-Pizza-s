
<?php $__env->startSection('content'); ?>

<div class="container center" style="width:40%; text-align: left; padding-top: 5em">
    <h4>Téléphone: 06 91 02 89 23</h4>
    <h4>Mail: fastpizzas@hotmail.com</h4> <br>
    <h4>Adresse: 1 rue de lyon, 75012 Paris</h4>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Software\Wamp\www\TM\TM3\Pizza\resources\views/contact.blade.php ENDPATH**/ ?>
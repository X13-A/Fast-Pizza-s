<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fast Pizza's</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/app.css')); ?>">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>
<body>
    <!-- Le header avec les boutons principaux. -->
    <header> 
        <img class="logo" src="<?php echo e(URL::asset('/img/logo.png')); ?>" alt="pizza" height="100" width="100">
        <ul class="nav__links">
            <li>
                <a href="<?php echo e(route('welcome')); ?>"> Accueil </a>
            </li>
            <li>
                <a href="<?php echo e(route('catalogue pizzas')); ?>"> Catalogue </a>
            </li>
            <li style="border: none;">
                <a href="<?php echo e(route('contact')); ?>"> Contact </a>
            </li>
        </ul>
        <!-- Menu utilisateur -->
        <div class="dropdown">
            <button class="btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <?php if(auth()->guard()->check()): ?>
                <span class="material-icons">face</span>
                <span><?php echo e(auth()->user()->prenom); ?> <?php echo e(auth()->user()->nom); ?></span>
                <?php endif; ?>
                <?php if(auth()->guard()->guest()): ?>
                <span class="material-icons">account_circle</span>
                <span>S'identifier</span>
                <?php endif; ?>
            </button>
            <div class="dropdown-menu bg-white" aria-labelledby="dropdownMenuButton">
                <?php if(auth()->guard()->check()): ?>
                    <a class="dropdown-item" href="<?php echo e(route('vue changer mot de passe')); ?>"> Changer mon mot de passe </a>
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" method="post"> Déconnexion </a>
                    <?php if(Auth::user()->type == 'user'): ?>
                        <a class="dropdown-item" href="<?php echo e(route('consulter commandes',['afficher'=>'tout'])); ?>"> Mes commandes </a>
                    <?php elseif(Auth::user()->type == 'admin'): ?>
                        <a class="dropdown-item" href="<?php echo e(route('gestion commandes')); ?>"> Gestion commandes</a>
                        <a class="dropdown-item" href="<?php echo e(route('gestion pizzas')); ?>"> Gestion pizzas</a>
                        <a class="dropdown-item" href="<?php echo e(route('gestion utilisateurs')); ?>"> Gestion Utilisateurs</a>
                    <?php elseif(Auth::user()->type == 'cook'): ?>
                        <a class="dropdown-item" href="<?php echo e(route('gestion commandes')); ?>"> Commandes</a>
                    <?php endif; ?>
                <?php endif; ?>
                <?php if(auth()->guard()->guest()): ?>
                    <a class="dropdown-item" href="<?php echo e(route('login')); ?>"> Se connecter </a>
                    <a class="dropdown-item" href="<?php echo e(route('register')); ?>"> S'inscrire </a>                
                <?php endif; ?>
            </div>
        </div>
    </header>
    
    <?php echo $__env->yieldContent('content'); ?>

    <div class="container" >
        <!-- Affichage des messages flash de confirmation si il y en a -->
        <?php if(session()->has('succes')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session()->get('succes')); ?>

            </div>
        <?php endif; ?>

        <!-- Affichage des messages flash d'erreur si il y en a -->
        <?php if(session()->has('erreur')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(session()->get('erreur')); ?>

            </div>
        <?php endif; ?>

        <!-- Affichage des messages flash d'erreurs de validation si il y en a -->
        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger" role="alert"> <?php echo e($error); ?> </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</body>
</html><?php /**PATH D:\Software\Wamp\www\TM\TM3\Pizza\resources\views/layouts/app.blade.php ENDPATH**/ ?>

<?php $__env->startSection('gestion'); ?>

<?php if($mode == 'commandes'): ?>
    <?php echo $__env->make('consultation.commandes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Software\Wamp\www\TM\TM3\Pizza\resources\views/consultation.blade.php ENDPATH**/ ?>
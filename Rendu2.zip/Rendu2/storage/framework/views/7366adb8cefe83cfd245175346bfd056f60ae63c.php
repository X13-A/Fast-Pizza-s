
<?php $__env->startSection('pizza'); ?>
<div class="container" style="margin-bottom: 3em; margin-top:2em;">
    <table id="catalogue" class="table table-striped table-bordered nowrap" style="width:100%">
        <thead>
            <tr>
                <th>Nom</th>
                <th>Description</th>
                <th>Prix</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pizzas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pizza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($pizza -> nom); ?> </td>
                    <td> <?php echo e($pizza -> description); ?> </td>
                    <td> <?php echo e($pizza -> prix); ?> </td>
                    <td> <a href=""> add to cart </a> </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.22/js/dataTables.bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/fixedheader/3.1.7/js/dataTables.fixedHeader.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.6/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.6/js/responsive.bootstrap.min.js  "></script>

<!-- Script permettant l'affichage de la datatable -->
<script> 
    $(document).ready(function() {
        var table = $('#catalogue').DataTable( {
            responsive: true
        } );
    
        new $.fn.dataTable.FixedHeader( catalogue );
    } );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('gestion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Software\Wamp\www\TM\TM3\Pizza\resources\views///gestion/pizza.blade.php ENDPATH**/ ?>
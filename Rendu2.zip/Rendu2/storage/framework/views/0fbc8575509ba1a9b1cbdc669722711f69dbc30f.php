<?php use App\Models\Pizza; ?>

<?php $__env->startSection('content'); ?>

<div class="container" style="margin-bottom: 3em; margin-top:2em;">
    <h3>Catalogue</h3>
    <table id="catalogue" class="table table-striped table-bordered nowrap" style="width:100%">
        <thead>
            <tr>
                <th>Pizza</th>
                <th>Ingrédients</th>
                <th>Prix</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pizzas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pizza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($pizza -> nom); ?> </td>
                    <td> <?php echo e($pizza -> description); ?> </td>
                    <td> <?php echo e($pizza -> prix); ?>€</td>
                    <td> <a class="material-icons shop" href="<?php echo e(route('ajouter panier',['pizza_id'=>$pizza->id])); ?>">add</a> </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($pizzas -> links()); ?>

</div>

<div class="container" style="margin-bottom: 3em; margin-top:2em;">
    <h3>Panier</h3>
    <table id="panier" class="table table-striped table-bordered nowrap" style="width:100%">
        <thead>
            <tr>
                <th>Pizza</th>
                <th>Quantité</th>
                <th>Prix</th>
            </tr>
        </thead>
        <tbody>
            <?php $panier = session()->get('panier'); ?>
            <?php if($panier != null): ?>
                <?php $__currentLoopData = $panier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td> <?php echo e($article["pizza"]); ?> </td>
                        <td> <?php echo e($article["qte"]); ?> </td>
                        <td> <?php echo e($article["prix"]); ?>€ </td>
                        <td> <a class="shop" href="<?php echo e(route('supprimer panier',['pizza_id'=>$article['pizza_id']])); ?>"> Enlever </a> </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
        <tfoot>
            <?php
                $total = 0;
                if ($panier != null) {
                    foreach ($panier as $article) {
                        $total += $article["prix"] * $article["qte"];
                    }
                }
                echo("<tr>");
                echo("<th>Total: $total €</th>");
                echo("</tr></table>");
            ?>
        </tfoot>
        <th><a class="shop" href="<?php echo e(route('envoyer commande')); ?>"> Envoyer la commande </a></th>
    </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Software\Wamp\www\TM\TM3\Pizza\resources\views//catalogue.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

<!-- <div class="container pt-4">
    <ul class="nav__links menu">
        <?php if(Auth::user()->type == 'user'): ?>
            <li>
                <a href="<?php echo e(route('catalogue pizzas')); ?>"> Catalogue </a>
            </li>
        <?php elseif(Auth::user()->type == 'cook'): ?>
            <li>
                <a href="<?php echo e(route('gestion commandes')); ?>"> Commandes</a>
            </li style="border: none;">
        <?php elseif(Auth::user()->type == 'admin'): ?>
            <li>
                <a href="<?php echo e(route('gestion commandes')); ?>"> Commandes</a>
            </li>
            <li>
                <a href="<?php echo e(route('gestion pizzas')); ?>"> Pizzas</a>
            </li>
            <li>
                <a href="<?php echo e(route('gestion utilisateurs')); ?>"> Utilisateurs</a>
            </li style="border: none;">            
        <?php endif; ?>
    </ul>
</div> -->

<?php echo $__env->yieldContent('gestion'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Software\Wamp\www\TM\TM3\Pizza\resources\views//dashboard.blade.php ENDPATH**/ ?>
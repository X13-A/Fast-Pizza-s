<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\PizzaController;
use App\Http\Controllers\PanierController;
use App\Http\Controllers\CommandeController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\UtilisateursController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register  web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/ 

// Pages principales

Route::get('/', [DashboardController::class, 'welcome']) -> name('welcome');
Route::get('/contact', [DashboardController::class, 'contact'])
    -> name('contact');
Route::get('/catalogue', [DashboardController::class, 'catalogue'])
    -> name('catalogue pizzas');

// Authentification

Route::get('/login', [AuthController::class, 'login_view']) -> name('login view');
Route::post('login', [AuthController::class, 'login']) -> name('login');
Route::get('/view_reset_password', [AuthController::class, 'resetPassword_view'])
    -> middleware('auth')
    -> name('vue changer mot de passe');

Route::post('reset_password', [AuthController::class, 'resetPassword'])
    -> middleware('auth')
    -> name('changer mot de passe');

Route::get('/register', [AuthController::class, 'register_view']) -> name('register view');
Route::post('register', [AuthController::class, 'register']) -> name('register');

Route::get('logout', [AuthController::class, 'logout'])
    -> middleware('auth')
    -> name('logout');

Route::get('/vue_changer_mdp_cuisto/{id}', [AuthController::class, 'vue_changer_mdp_cuisto'])
    -> middleware('auth')
    -> middleware('isAdmin')
    -> name('vue changer mdp cuisto');

Route::post('/changer_mdp_cuisto', [AuthController::class, 'changer_mdp_cuisto'])
    -> middleware('auth')
    -> middleware('isAdmin')
    -> name('changer mdp cuisto');

Route::post('reset_password', [AuthController::class, 'resetPassword'])
    -> middleware('auth')
    -> name('changer mot de passe');

// Panier

Route::get('/ajouter_panier/{pizza_id}/', [PanierController::class, 'ajouter'])
    -> name('ajouter panier');

Route::get('/supprimer_panier/{pizza_id}/', [PanierController::class, 'supprimer'])
    -> name('supprimer panier');

Route::get('/envoyer_commande/', [PanierController::class, 'envoyer'])
    -> middleware('auth')
    -> name('envoyer commande');

// Gestion

Route::get('/gestion_pizzas', [PizzaController::class, 'gestionPizzas'])
    -> middleware('auth')
    -> middleware('isAdmin')
    -> name('gestion pizzas');

Route::get('/gestion_commandes', [CommandeController::class, 'gestionCommandes'])
    -> middleware('auth')
    -> middleware('isCook')
    -> name('gestion commandes');

Route::get('/gestion_utilisateurs', [UtilisateursController::class, 'gestionUtilisateurs'])
    -> middleware('auth')
    -> middleware('isAdmin')
    -> name('gestion utilisateurs');

// Pizzas

Route::post('/ajout_pizza', [PizzaController::class, 'ajouter'])
    -> name('ajout pizza')
    -> middleware('auth')
    -> middleware('isAdmin');

Route::get('/vue_modif_pizza/{id}', [PizzaController::class, 'vue_modifier'])
    -> middleware('auth')
    -> middleware('isAdmin')
    -> name('vue modif pizza');

Route::post('/modif_pizza/{id}', [PizzaController::class, 'modifier'])
    -> middleware('auth')
    -> middleware('isAdmin')
    -> name('modif pizza');

Route::get('/vue_suppr_pizza/{id}', [PizzaController::class, 'vue_supprimer'])
    -> middleware('auth')
    -> middleware('isAdmin')
    -> name('vue supprimer pizza');

Route::get('/suppr_pizza/{id}', [PizzaController::class, 'supprimer'])
    -> middleware('auth')
    -> middleware('isAdmin')
    -> name('supprimer pizza');

// Commandes

Route::get('/consulter_commandes/{afficher}/', [CommandeController::class, 'consulterCommandes'])
    -> middleware('auth')
    -> name('consulter commandes');

Route::get('/modif_statut/{id}/{statut}/', [CommandeController::class, 'modif_statut'])
    -> middleware('auth')
    -> middleware('isCook')       
    -> name('modif statut');

Route::get('/recherche_commande', [CommandeController::class, 'recherche'])
    -> middleware('auth')
    -> middleware('isAdmin')       
    -> name('recherche commande');

// utilisateurs

Route::get('/ajout_utilisateur', [UtilisateursController::class, 'ajouter'])
    -> middleware('auth')
    -> middleware('isAdmin')       
    -> name('ajout utilisateur');

Route::get('/vue_suppr_utilisateur/{id}', [UtilisateursController::class, 'vue_supprimer'])
    -> middleware('auth')
    -> middleware('isAdmin')       
    -> name('vue supprimer utilisateur');

Route::get('/suppr_utilisateur/{id}', [UtilisateursController::class, 'supprimer'])
    -> middleware('auth')
    -> middleware('isAdmin')
    -> name('supprimer utilisateur');

Route::get('/vue_modif_cuisto/{id}', [UtilisateursController::class, 'vue_modif_cuisto'])
    -> middleware('auth')
    -> middleware('isAdmin')
    -> name('vue modif cuisto');
